// Niche lookup. Each niche carries the customer-facing copy from the ECO MATRIX
// copy pack (tokens {{business}} {{city}} {{state}} {{phone}} {{rating}} {{reviews}}
// are filled at render time). The hero image is selected by niche, not per business.

export type Niche =
  | 'septic'
  | 'tree'
  | 'pressure_wash'
  | 'well_water'
  | 'fence'
  | 'cleaning'
  | 'junk_removal'
  | 'roofing'
  | 'excavating'
  | 'plumbing'
  | 'hvac'
  | 'landscaping';

export type NicheConfig = {
  label: string;
  tagline: string;
  /** Expanded service list (4–6 items). */
  services: string[];
  heroImage: string;
  accent: string;
  gradient: [string, string];
  /** Hero headline (opens on the gap). */
  h1: string;
  /** Hero subhead. */
  sub: string;
  /** Problem/"gap" paragraph. */
  gap: string;
  /** Final close line, shown above the call CTA. */
  close: string;
};

export const NICHES: Record<Niche, NicheConfig> = {
  hvac: {
    label: 'Heating & Air',
    tagline: 'Comfort You Can Count On',
    services: [
      'AC Repair',
      'Furnace Repair',
      'New System Install',
      'Tune-Ups & Maintenance',
      'Emergency Heating & Cooling',
      'Indoor Air Quality'
    ],
    heroImage: '/heroes/hvac.webp',
    accent: '#dc2626',
    gradient: ['#3b0a0a', '#dc2626'],
    h1: 'No heat? No cool? {{business}} answers {{city}} day and night.',
    sub: 'When the furnace quits on the coldest night or the AC dies in a heat wave, you need a real person, fast. We pick up and get a tech rolling.',
    gap: "A no-heat call at 2am isn't a leave-a-message situation. {{business}} answers when it matters, books you on the spot, and gets someone out before you're shivering through the night.",
    close: 'Make the call. Stay comfortable.'
  },
  septic: {
    label: 'Septic Services',
    tagline: 'Dependable Septic Service, Done Right',
    services: [
      'Tank Pumping',
      'Inspections',
      'Drainfield Repair',
      'New System Install',
      'Emergency Backups',
      'Line Cleaning'
    ],
    heroImage: '/heroes/septic.webp',
    accent: '#1d4ed8',
    gradient: ['#0f172a', '#1d4ed8'],
    h1: 'Septic backing up in {{city}}? {{business}} answers now.',
    sub: "A backup doesn't wait for business hours. We pick up, we come out, we fix it before it gets worse.",
    gap: "When a tank backs up into the house, you're not leaving voicemails for three companies. {{business}} answers the first call and gets a truck headed your way.",
    close: "Make the call. We'll handle the mess."
  },
  tree: {
    label: 'Tree Service',
    tagline: 'Tree Care You Can Count On',
    services: [
      'Tree Removal',
      'Trimming & Pruning',
      'Storm & Emergency Removal',
      'Stump Grinding',
      'Lot Clearing',
      'Hazard Assessment'
    ],
    heroImage: '/heroes/tree.webp',
    accent: '#15803d',
    gradient: ['#14532d', '#15803d'],
    h1: 'Tree down in {{city}}? {{business}} is already answering.',
    sub: 'A storm drops a limb on your roof and you need it gone today. We pick up, we assess, we clear it.',
    gap: 'A branch through the roof after a storm is a same-day job, and it goes to whoever answers first. {{business}} answers first.',
    close: "Make the call. We'll get it down."
  },
  well_water: {
    label: 'Well & Water Service',
    tagline: 'Clean Water, Reliable Wells',
    services: [
      'Pump Repair & Replacement',
      'New Well Drilling',
      'Pressure Tanks',
      'Water Testing',
      'Filtration',
      'No-Water Emergencies'
    ],
    heroImage: '/heroes/well_water.webp',
    accent: '#0369a1',
    gradient: ['#0c2a3e', '#0369a1'],
    h1: 'No water in {{city}}? {{business}} picks up.',
    sub: "When the well quits and the taps run dry, it's a today problem. We answer and get your water back on.",
    gap: "A house with no water can't wait until Monday. {{business}} answers the call, diagnoses the pump, and gets the water flowing again.",
    close: 'Make the call. Get your water back.'
  },
  roofing: {
    label: 'Roofing',
    tagline: 'Roofs Done Right, Rain or Shine',
    services: [
      'Leak Repair',
      'Full Replacement',
      'Storm Damage',
      'Inspections',
      'Gutters',
      'Emergency Tarping'
    ],
    heroImage: '/heroes/roofing.webp',
    accent: '#b91c1c',
    gradient: ['#450a0a', '#b91c1c'],
    h1: 'Roof leaking in {{city}}? {{business}} answers before the next storm.',
    sub: 'A leak after a storm only gets worse. We pick up, tarp it fast, and get you a real fix.',
    gap: 'Water through the ceiling is a today call, and a new roof goes to whoever picks up. {{business}} answers, protects the house, and quotes the job straight.',
    close: 'Make the call. Keep it dry.'
  },
  excavating: {
    label: 'Excavating',
    tagline: 'Ground Broken, Jobs Finished',
    services: [
      'Site Prep',
      'Grading',
      'Foundation Digs',
      'Trenching',
      'Land Clearing',
      'Drainage'
    ],
    heroImage: '/heroes/excavating.webp',
    accent: '#a16207',
    gradient: ['#422006', '#a16207'],
    h1: 'Breaking ground in {{city}}? {{business}} answers and shows up.',
    sub: 'Site prep, grading, drainage. We pick up, walk your job, and get dirt moving on your timeline.',
    gap: 'A dig job stalls the second nobody calls you back. {{business}} answers, gets eyes on the site, and keeps your build on schedule.',
    close: "Make the call. We'll move the dirt."
  },
  plumbing: {
    label: 'Plumbing',
    tagline: 'Fast, Honest Plumbing',
    services: [
      'Leak & Burst Repair',
      'Water Heaters',
      'Drain Cleaning',
      'Repipes',
      'Fixtures',
      '24/7 Emergencies'
    ],
    heroImage: '/heroes/plumbing.webp',
    accent: '#1e40af',
    gradient: ['#0c1838', '#1e40af'],
    h1: 'Burst pipe in {{city}}? {{business}} answers at any hour.',
    sub: "Water where it shouldn't be can't wait. We pick up and get a plumber to your door.",
    gap: 'A burst line at midnight has them calling until someone answers. {{business}} is the one who picks up, and the one who books the job.',
    close: "Make the call. We'll shut it off and fix it."
  },
  fence: {
    label: 'Fencing',
    tagline: 'Fences Built to Last',
    services: [
      'Wood, Vinyl & Chain-Link',
      'Ranch Fencing',
      'Gates',
      'Repairs',
      'Commercial',
      'Free Estimates'
    ],
    heroImage: '/heroes/fence.webp',
    accent: '#b45309',
    gradient: ['#451a03', '#b45309'],
    h1: 'Need a fence in {{city}}? {{business}} answers and quotes fast.',
    sub: 'Most folks call three companies. The first to answer gets the job. We answer.',
    gap: "A fence quote shouldn't take a week of phone tag. {{business}} picks up, gets your details, and gets you a number while the others are still letting it ring.",
    close: 'Make the call. Get your quote today.'
  },
  pressure_wash: {
    label: 'Pressure Washing',
    tagline: 'Making Your Property Look New Again',
    services: [
      'House Washing',
      'Driveways & Concrete',
      'Decks & Fences',
      'Roofs & Gutters',
      'Commercial',
      'Free Estimates'
    ],
    heroImage: '/heroes/pressure_wash.webp',
    accent: '#0891b2',
    gradient: ['#083344', '#0891b2'],
    h1: 'Grime taking over in {{city}}? {{business}} picks up and gets it gone.',
    sub: 'Driveways, siding, decks — we answer, quote, and make it look new again.',
    gap: 'Most pressure-washing quotes die in voicemail. {{business}} answers, gets your details, and gets on the schedule while the others let it ring.',
    close: "Make the call. We'll make it look new."
  },
  cleaning: {
    label: 'Cleaning Service',
    tagline: 'A Cleaner Home, Every Time',
    services: [
      'Deep Cleaning',
      'Recurring Service',
      'Carpet & Floor',
      'Move-In / Move-Out',
      'Offices',
      'Free Estimates'
    ],
    heroImage: '/heroes/cleaning.webp',
    accent: '#7c3aed',
    gradient: ['#2e1065', '#7c3aed'],
    h1: 'Need it spotless in {{city}}? {{business}} answers and books you in.',
    sub: 'Homes, carpets, move-outs — we pick up, quote, and get you on the calendar.',
    gap: "A cleaning quote shouldn't take a week of phone tag. {{business}} answers, gets your details, and locks the date.",
    close: "Make the call. We'll handle the rest."
  },
  junk_removal: {
    label: 'Junk Removal',
    tagline: 'Haul It Away, Same Day',
    services: [
      'Junk Hauling',
      'Estate Cleanouts',
      'Same-Day Pickup',
      'Furniture & Appliances',
      'Construction Debris',
      'Free Estimates'
    ],
    heroImage: '/heroes/junk_removal.webp',
    accent: '#ea580c',
    gradient: ['#431407', '#ea580c'],
    h1: 'Need it hauled in {{city}}? {{business}} answers and shows up.',
    sub: 'One item or a whole house — we pick up, quote, and haul it the same day.',
    gap: 'Junk hauling goes to whoever answers and shows up. {{business}} picks up, gives you a number, and gets it gone — often same day.',
    close: "Make the call. We'll clear it out."
  },
  landscaping: {
    label: 'Landscaping',
    tagline: 'Yards Worth Coming Home To',
    services: [
      'Lawn Care & Mowing',
      'Cleanups & Hauling',
      'Mulch & Flower Beds',
      'Trees & Shrubs',
      'Sod & Seeding',
      'Free Estimates'
    ],
    heroImage: '/heroes/landscaping.webp',
    accent: '#4d7c0f',
    gradient: ['#1a2e05', '#4d7c0f'],
    h1: 'Yard getting away from you in {{city}}? {{business}} answers and shows up.',
    sub: 'Mowing, cleanups, beds, and full makeovers — we pick up, quote, and get on the schedule.',
    gap: "A landscaping quote shouldn't take a week of phone tag. {{business}} answers, walks your yard, and gets you a number while the others let it ring.",
    close: "Make the call. We'll make it sharp."
  }
};

export const NICHE_KEYS = Object.keys(NICHES) as Niche[];

export function isNiche(value: string): value is Niche {
  return value in NICHES;
}

export function servicesForNiche(niche: Niche): string[] {
  return NICHES[niche].services;
}
